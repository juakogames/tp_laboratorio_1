#include <stdio.h>
#include <stdlib.h>
#include "TP--1.h"

int main(void)
{
    menu();

    return 0;
}
